// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize all features
    initSmoothScrolling();
    initAnimationOnScroll();
    initTableOfContents();
    initSearchFunctionality();
    initThemeToggle();
    initPrintFunctionality();
    initCopyToClipboard();
    initProgressBar();
});

// Smooth Scrolling for internal links
function initSmoothScrolling() {
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Animation on Scroll
function initAnimationOnScroll() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);

    // Observe all sections
    const sections = document.querySelectorAll('section');
    sections.forEach(section => {
        section.style.opacity = '0';
        section.style.transform = 'translateY(30px)';
        section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(section);
    });
}

// Table of Contents Generator
function initTableOfContents() {
    const tocContainer = createTOCContainer();
    const headings = document.querySelectorAll('h2, h3, h4');
    
    if (headings.length === 0) return;
    
    const tocList = document.createElement('ul');
    tocList.className = 'toc-list';
    
    headings.forEach((heading, index) => {
        // Add ID to heading if it doesn't have one
        if (!heading.id) {
            heading.id = `heading-${index}`;
        }
        
        const listItem = document.createElement('li');
        listItem.className = `toc-item toc-${heading.tagName.toLowerCase()}`;
        
        const link = document.createElement('a');
        link.href = `#${heading.id}`;
        link.textContent = heading.textContent;
        link.className = 'toc-link';
        
        listItem.appendChild(link);
        tocList.appendChild(listItem);
    });
    
    tocContainer.appendChild(tocList);
    
    // Add toggle functionality
    const tocToggle = tocContainer.querySelector('.toc-toggle');
    const tocContent = tocContainer.querySelector('.toc-content');
    
    tocToggle.addEventListener('click', function() {
        tocContent.classList.toggle('toc-open');
        this.classList.toggle('active');
    });
}

function createTOCContainer() {
    const tocContainer = document.createElement('div');
    tocContainer.className = 'toc-container';
    tocContainer.innerHTML = `
        <button class="toc-toggle" aria-label="Toggle Table of Contents">
            <span class="toc-icon">📋</span>
            <span class="toc-text">Daftar Isi</span>
        </button>
        <div class="toc-content">
            <h3>Daftar Isi</h3>
        </div>
    `;
    
    document.body.appendChild(tocContainer);
    
    // Add CSS for TOC
    const tocStyles = `
        .toc-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            max-width: 300px;
        }
        
        .toc-toggle {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.75rem 1rem;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.9rem;
            font-weight: 500;
            transition: all 0.3s ease;
            width: 100%;
        }
        
        .toc-toggle:hover {
            background: var(--secondary-color);
        }
        
        .toc-toggle.active {
            border-bottom-left-radius: 0;
            border-bottom-right-radius: 0;
        }
        
        .toc-content {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease;
            background: white;
            border-bottom-left-radius: 8px;
            border-bottom-right-radius: 8px;
        }
        
        .toc-content.toc-open {
            max-height: 400px;
            overflow-y: auto;
        }
        
        .toc-content h3 {
            margin: 0;
            padding: 1rem 1rem 0.5rem;
            font-size: 1rem;
            color: var(--primary-color);
            border-bottom: 1px solid var(--border-color);
        }
        
        .toc-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .toc-item {
            border-bottom: 1px solid var(--border-color);
        }
        
        .toc-item:last-child {
            border-bottom: none;
        }
        
        .toc-link {
            display: block;
            padding: 0.5rem 1rem;
            text-decoration: none;
            color: var(--text-dark);
            font-size: 0.85rem;
            transition: all 0.3s ease;
        }
        
        .toc-link:hover {
            background: var(--light-bg);
            color: var(--accent-color);
        }
        
        .toc-h2 .toc-link {
            font-weight: 600;
            padding-left: 1rem;
        }
        
        .toc-h3 .toc-link {
            padding-left: 1.5rem;
            font-size: 0.8rem;
        }
        
        .toc-h4 .toc-link {
            padding-left: 2rem;
            font-size: 0.75rem;
            color: var(--text-light);
        }
        
        @media (max-width: 768px) {
            .toc-container {
                position: relative;
                top: auto;
                right: auto;
                margin: 1rem;
                max-width: none;
            }
        }
    `;
    
    const styleSheet = document.createElement('style');
    styleSheet.textContent = tocStyles;
    document.head.appendChild(styleSheet);
    
    return tocContainer;
}

// Search Functionality
function initSearchFunctionality() {
    const searchContainer = createSearchContainer();
    const searchInput = searchContainer.querySelector('.search-input');
    const searchResults = searchContainer.querySelector('.search-results');
    
    let searchTimeout;
    
    searchInput.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        const query = this.value.trim();
        
        if (query.length < 2) {
            searchResults.innerHTML = '';
            searchResults.style.display = 'none';
            return;
        }
        
        searchTimeout = setTimeout(() => {
            performSearch(query, searchResults);
        }, 300);
    });
    
    // Close search results when clicking outside
    document.addEventListener('click', function(e) {
        if (!searchContainer.contains(e.target)) {
            searchResults.style.display = 'none';
        }
    });
}

function createSearchContainer() {
    const searchContainer = document.createElement('div');
    searchContainer.className = 'search-container';
    searchContainer.innerHTML = `
        <div class="search-box">
            <input type="text" class="search-input" placeholder="Cari dalam dokumen..." aria-label="Search">
            <span class="search-icon">🔍</span>
        </div>
        <div class="search-results"></div>
    `;
    
    // Insert after header
    const header = document.querySelector('.header');
    header.insertAdjacentElement('afterend', searchContainer);
    
    // Add CSS for search
    const searchStyles = `
        .search-container {
            position: relative;
            max-width: 600px;
            margin: -1rem auto 2rem;
            padding: 0 2rem;
            z-index: 100;
        }
        
        .search-box {
            position: relative;
            background: white;
            border-radius: 25px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .search-input {
            width: 100%;
            padding: 1rem 3rem 1rem 1.5rem;
            border: none;
            outline: none;
            font-size: 1rem;
            background: transparent;
        }
        
        .search-icon {
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-light);
        }
        
        .search-results {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            max-height: 300px;
            overflow-y: auto;
            display: none;
            z-index: 1000;
        }
        
        .search-result-item {
            padding: 1rem;
            border-bottom: 1px solid var(--border-color);
            cursor: pointer;
            transition: background 0.3s ease;
        }
        
        .search-result-item:hover {
            background: var(--light-bg);
        }
        
        .search-result-item:last-child {
            border-bottom: none;
        }
        
        .search-result-title {
            font-weight: 600;
            color: var(--primary-color);
            margin-bottom: 0.25rem;
        }
        
        .search-result-snippet {
            font-size: 0.9rem;
            color: var(--text-light);
            line-height: 1.4;
        }
        
        .search-highlight {
            background: yellow;
            padding: 0 2px;
            border-radius: 2px;
        }
        
        @media (max-width: 768px) {
            .search-container {
                padding: 0 1rem;
            }
        }
    `;
    
    const styleSheet = document.createElement('style');
    styleSheet.textContent = searchStyles;
    document.head.appendChild(styleSheet);
    
    return searchContainer;
}

function performSearch(query, resultsContainer) {
    const sections = document.querySelectorAll('section');
    const results = [];
    
    sections.forEach(section => {
        const title = section.querySelector('h2, h3, h4')?.textContent || 'Untitled Section';
        const content = section.textContent.toLowerCase();
        const queryLower = query.toLowerCase();
        
        if (content.includes(queryLower)) {
            const index = content.indexOf(queryLower);
            const start = Math.max(0, index - 50);
            const end = Math.min(content.length, index + query.length + 50);
            let snippet = section.textContent.substring(start, end);
            
            // Highlight the search term
            const regex = new RegExp(`(${query})`, 'gi');
            snippet = snippet.replace(regex, '<span class="search-highlight">$1</span>');
            
            results.push({
                title,
                snippet,
                element: section
            });
        }
    });
    
    displaySearchResults(results, resultsContainer);
}

function displaySearchResults(results, container) {
    if (results.length === 0) {
        container.innerHTML = '<div class="search-result-item">Tidak ada hasil ditemukan</div>';
    } else {
        container.innerHTML = results.map(result => `
            <div class="search-result-item" data-section="${result.element.id || ''}">
                <div class="search-result-title">${result.title}</div>
                <div class="search-result-snippet">${result.snippet}...</div>
            </div>
        `).join('');
        
        // Add click handlers
        container.querySelectorAll('.search-result-item').forEach((item, index) => {
            item.addEventListener('click', () => {
                results[index].element.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
                container.style.display = 'none';
            });
        });
    }
    
    container.style.display = 'block';
}

// Theme Toggle (Light/Dark mode)
function initThemeToggle() {
    const themeToggle = document.createElement('button');
    themeToggle.className = 'theme-toggle';
    themeToggle.innerHTML = '🌙';
    themeToggle.setAttribute('aria-label', 'Toggle dark mode');
    
    document.body.appendChild(themeToggle);
    
    // Add CSS for theme toggle
    const themeStyles = `
        .theme-toggle {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: none;
            background: var(--primary-color);
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            transition: all 0.3s ease;
            z-index: 1000;
        }
        
        .theme-toggle:hover {
            transform: scale(1.1);
            background: var(--secondary-color);
        }
        
        @media (max-width: 768px) {
            .theme-toggle {
                bottom: 80px;
            }
        }
    `;
    
    const styleSheet = document.createElement('style');
    styleSheet.textContent = themeStyles;
    document.head.appendChild(styleSheet);
    
    // Theme toggle functionality
    themeToggle.addEventListener('click', function() {
        document.body.classList.toggle('dark-theme');
        this.innerHTML = document.body.classList.contains('dark-theme') ? '☀️' : '🌙';
        
        // Save preference
        localStorage.setItem('darkTheme', document.body.classList.contains('dark-theme'));
    });
    
    // Load saved theme
    if (localStorage.getItem('darkTheme') === 'true') {
        document.body.classList.add('dark-theme');
        themeToggle.innerHTML = '☀️';
    }
}

// Print Functionality
function initPrintFunctionality() {
    const printButton = document.createElement('button');
    printButton.className = 'print-button';
    printButton.innerHTML = '🖨️';
    printButton.setAttribute('aria-label', 'Print document');
    
    document.body.appendChild(printButton);
    
    // Add CSS for print button
    const printStyles = `
        .print-button {
            position: fixed;
            bottom: 80px;
            right: 20px;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: none;
            background: var(--accent-color);
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            transition: all 0.3s ease;
            z-index: 1000;
        }
        
        .print-button:hover {
            transform: scale(1.1);
            background: #2980b9;
        }
        
        @media (max-width: 768px) {
            .print-button {
                bottom: 140px;
            }
        }
    `;
    
    const styleSheet = document.createElement('style');
    styleSheet.textContent = printStyles;
    document.head.appendChild(styleSheet);
    
    printButton.addEventListener('click', function() {
        window.print();
    });
}

// Copy to Clipboard for Arabic text
function initCopyToClipboard() {
    const arabicTexts = document.querySelectorAll('.arabic-text, .arabic-quote');
    
    arabicTexts.forEach(text => {
        const copyButton = document.createElement('button');
        copyButton.className = 'copy-button';
        copyButton.innerHTML = '📋';
        copyButton.setAttribute('aria-label', 'Copy Arabic text');
        copyButton.title = 'Salin teks Arab';
        
        text.style.position = 'relative';
        text.appendChild(copyButton);
        
        copyButton.addEventListener('click', async function() {
            try {
                await navigator.clipboard.writeText(text.textContent);
                this.innerHTML = '✅';
                setTimeout(() => {
                    this.innerHTML = '📋';
                }, 2000);
            } catch (err) {
                console.error('Failed to copy text: ', err);
            }
        });
    });
    
    // Add CSS for copy button
    const copyStyles = `
        .copy-button {
            position: absolute;
            top: 0.5rem;
            left: 0.5rem;
            width: 30px;
            height: 30px;
            border: none;
            background: rgba(255, 255, 255, 0.9);
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.8rem;
            transition: all 0.3s ease;
            opacity: 0;
        }
        
        .arabic-text:hover .copy-button,
        .arabic-quote:hover .copy-button {
            opacity: 1;
        }
        
        .copy-button:hover {
            background: white;
            transform: scale(1.1);
        }
    `;
    
    const styleSheet = document.createElement('style');
    styleSheet.textContent = copyStyles;
    document.head.appendChild(styleSheet);
}

// Reading Progress Bar
function initProgressBar() {
    const progressBar = document.createElement('div');
    progressBar.className = 'progress-bar';
    document.body.appendChild(progressBar);
    
    // Add CSS for progress bar
    const progressStyles = `
        .progress-bar {
            position: fixed;
            top: 0;
            left: 0;
            width: 0%;
            height: 3px;
            background: var(--accent-color);
            z-index: 9999;
            transition: width 0.3s ease;
        }
    `;
    
    const styleSheet = document.createElement('style');
    styleSheet.textContent = progressStyles;
    document.head.appendChild(styleSheet);
    
    // Update progress on scroll
    window.addEventListener('scroll', function() {
        const scrollTop = window.pageYOffset;
        const docHeight = document.body.scrollHeight - window.innerHeight;
        const scrollPercent = (scrollTop / docHeight) * 100;
        
        progressBar.style.width = scrollPercent + '%';
    });
}

// Utility function to debounce events
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

