# Situs Web Pembahasan Hadits - Syeikh Al-Albani

## Deskripsi
Situs web ini menampilkan pembahasan mendalam dari Syeikh Al-Albani tentang hadits tabarruk. Konten telah dipertahankan sesuai aslinya tanpa perubahan kalimat, dengan desain yang rapi dan modern.

## Fitur-Fitur

### 1. **Desain Responsif**
- Tampilan optimal di desktop, tablet, dan mobile
- Layout yang menyesuaikan ukuran layar
- Tipografi yang mudah dibaca

### 2. **Pencarian Dokumen**
- Fitur pencarian real-time
- Highlight kata kunci yang dicari
- Hasil pencarian dengan snippet konteks

### 3. **Daftar Isi Interaktif**
- Navigasi cepat ke bagian tertentu
- Smooth scrolling
- Indikator visual untuk setiap bagian

### 4. **Mode Gelap/Terang**
- Toggle antara mode terang dan gelap
- Preferensi tersimpan di browser
- Tombol floating di kanan bawah (🌙/☀️)

### 5. **Fitur Cetak**
- Optimasi untuk pencetakan
- Tombol cetak floating (🖨️)
- Layout yang printer-friendly

### 6. **Teks Arab**
- Font Amiri untuk teks Arab yang jelas
- Arah teks RTL yang benar
- Tombol copy untuk teks Arab

### 7. **Progress Bar**
- Indikator progress membaca di bagian atas
- Update real-time saat scroll

## Struktur Konten

### Bagian Utama:
1. **Penarikan Kembali Penshahihan** - Pengantar dari Syeikh Al-Albani
2. **Hadits dan Status** - Teks hadits dengan status "munkar"
3. **Sumber Riwayat** - Ath-Thabarani, Ibn 'Adiy, Abu Nu'aim
4. **Sanad Hadits** - Rantai periwayatan
5. **Dialog dalam Hadits** - Percakapan antara Ibnu Umar dan Rasulullah ﷺ
6. **Analisis Syeikh Al-Albani** - Pembahasan mendalam tentang perawi
7. **Kesimpulan** - Prinsip penelitian hadits dan peringatan

### Warna Coding:
- **Merah**: Hadits munkar dan pertanyaan
- **Hijau**: Terjemahan dan jawaban
- **Kuning**: Sanad dan kelanjutan
- **Biru**: Analisis dan kesimpulan
- **Abu-abu**: Kutipan dan referensi

## Cara Penggunaan

### Membuka Situs Web:
1. Buka file `index.html` di browser web
2. Atau gunakan web server lokal untuk pengalaman optimal

### Navigasi:
- **Scroll**: Gunakan mouse wheel atau touch gesture
- **Daftar Isi**: Klik tombol "📋 Daftar Isi" di kanan atas
- **Pencarian**: Ketik kata kunci di kotak pencarian
- **Mode Gelap**: Klik tombol 🌙 di kanan bawah

### Fitur Khusus:
- **Copy Teks Arab**: Hover pada teks Arab dan klik tombol 📋
- **Cetak**: Klik tombol 🖨️ untuk mencetak dokumen
- **Zoom**: Gunakan Ctrl+/Ctrl- untuk memperbesar/memperkecil

## File yang Disertakan

1. **index.html** - File HTML utama
2. **styles.css** - Stylesheet untuk desain dan layout
3. **script.js** - JavaScript untuk interaktivitas
4. **README.md** - Dokumentasi ini

## Kompatibilitas Browser

- ✅ Chrome 80+
- ✅ Firefox 75+
- ✅ Safari 13+
- ✅ Edge 80+

## Teknologi yang Digunakan

- **HTML5** - Struktur semantik
- **CSS3** - Styling modern dengan Flexbox dan Grid
- **JavaScript ES6+** - Interaktivitas dan fitur dinamis
- **Google Fonts** - Tipografi (Inter dan Amiri)

## Catatan Penting

- Konten telah dipertahankan sesuai aslinya tanpa perubahan
- Teks Arab menggunakan font Amiri untuk keterbacaan optimal
- Semua kutipan dan referensi dipertahankan persis seperti aslinya
- Desain responsif memastikan aksesibilitas di semua perangkat

## Dukungan

Jika mengalami masalah atau membutuhkan modifikasi, silakan hubungi pengembang.

---

**Dibuat dengan**: HTML5, CSS3, JavaScript  
**Font**: Inter (Latin), Amiri (Arab)  
**Tanggal**: 2024

